import React from 'react'

function admin_home() {
  return (
    <div>admin_home</div>
  )
}

export default admin_home
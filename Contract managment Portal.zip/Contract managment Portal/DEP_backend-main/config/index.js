const adminReq = require('./adminReq.config');
const authConfig = require('./auth.config')
const config = require('./db.config');
const refreshConfig = require('./refresh.config');

module.exports ={
    adminReq,
    authConfig,
    config,
    refreshConfig
}
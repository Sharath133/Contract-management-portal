module.exports = {
    secret: 'admin-key'
}